﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Telegram.Bot;
using Telegram.Bot.Args;
using Telegram.Bot.Exceptions;
using Telegram.Bot.Extensions.Polling;
using Telegram.Bot.Types;
using Telegram.Bot.Types.Enums;
namespace TelegramBot
{
    class Program
    {
        static TelegramBotClient botClient = new TelegramBotClient("5081332639:AAESZ_A2bJ2Pfald_WqdycvUBd5vgFV2-sg");

       

        static void Main(string[] args)
        {
            botClient.OnMessage += Bot_OnMessage;

            botClient.StartReceiving();
            Console.ReadLine();
            botClient.StopReceiving();
        }

        private static void Bot_OnMessage(object sender,Telegram.Bot.Args. MessageEventArgs e)
        {
            if (e.Message.Type == Telegram.Bot.Types.Enums.MessageType.Text)
            {
                if (e.Message.Text == "Hello")
                    botClient.SendTextMessageAsync(e.Message.Chat.Id, "Hi");
                else if (e.Message.Text == "pic")
                {
                    botClient.SendStickerAsync(e.Message.Chat.Id, "https://github.com/TelegramBots/book/raw/master/src/docs/sticker-fred.webp");
                }

                else if (e.Message.Text == "date")
                {
                    botClient.SendTextMessageAsync(e.Message.Chat.Id, DateTime.Now.ToString("yyyy-MM-dd"));
                }
                else if (e.Message.Text == "time")
                {
                    botClient.SendTextMessageAsync(e.Message.Chat.Id, DateTime.Now.ToString("hh:mm:ss tt"));
                }
                else if (e.Message.Text == "Audio")
                {
                    botClient.SendAudioAsync(e.Message.Chat.Id, "https://github.com/TelegramBots/book/raw/master/src/docs/audio-guitar.mp3");
                }
            }
            }
    }
}
